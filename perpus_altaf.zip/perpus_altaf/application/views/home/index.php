<div class="container">    

    <div style="margin-top: 10%;"> 
        <center>  
            <h3>Daftar Peminjaman Buku</h3>
        </center>
        <?php if( $this->session->flashdata('flash')): ?>
        <div class="row mt-3">
            <div class="col-md-6">
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    Data Peminjaman Buku <strong>berhasil</strong> <?= $this->session->flashdata('flash'); ?>.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                    </button>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="mt-3">
            <div class="float-end">
                <a href="<?= base_url(); ?>home/tambah" class="btn btn-primary">Tambah Data</a>
            </div>
        </div>

        <table class="table table-striped table-hover" style="margin-bottom: 16%;">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>NIS</th>
                    <th>Kelas</th>
                    <th>Judul Buku</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    <th>Aksi</th>
                </tr>
            </thead>
                <?php
                $no = 1; 
                foreach( $buku as $bk ) :
                ?>
            <tbody>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $bk['nama_lengkap'] ?></td>
                    <td><?= $bk['nis'] ?></td>
                    <td><?= $bk['kelas'] ?></td>
                    <td><?= $bk['judul_buku'] ?></td>
                    <td><?= $bk['tgl_pinjam'] ?></td>
                    <td><?= $bk['tgl_kembali'] ?></td>
                    <td>
                        <a style="text-decoration: none;" href="<?php base_url(); ?>home/hapus/<?= $bk['id'];?>" class="badge bg-danger" onclick="return confirm('yakin?');">hapus</a>
                        <a style="text-decoration: none;" href="<?php base_url(); ?>home/ubah/<?= $bk['id'];?>" class="badge bg-success">ubah</a>
                    </td>
                </tr>
            </tbody>
            <?php endforeach?>
        </table>
    </div>
    <!-- <div class="d-flex justify-content-center" style="margin-bottom:11%">
        <a href="<?= base_url(); ?>"></a><button class="btn btn-dark mt-3">logout</button>
    </div > -->
</div>