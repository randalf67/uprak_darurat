<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <title>Login</title>
</head>
<body>
    <marquee behavior="" direction="">
    <?php
    $info = $this->session->flashdata('info');
    if (!empty($info)){
     echo $info;
    }
     ?>
    </marquee>
    
    <center>
        <div class="card" style="width: 50%; margin-top: 10%;">
            <form action="<?= base_url(); ?>login2/proses" method="post">
                <h1>LOGIN</h1>
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="username" name="username" class="form-control" id="username" aria-describedby="usernameHelp" style="width: 50%;border-radius: 10px;">
                    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="password" style="width: 50%;border-radius: 10px;">
                    <div id="passHelp" class="form-text"><div id="emailHelp" class="form-text">Your password must be 8-20 characters long.</div>
                </div>
                <button type="submit" class="btn btn-primary" style="margin-top: 10px;">Submit</button>
                
            </form>
            <a href="<?php echo base_url() ?>register2/register"><button type="button" class="btn btn-primary" style="margin-top: 10px;">register</button></a>
            <!-- <button><a href="<?php base_url() ?>login" type="button">login</a></button> -->
        </div>
    </center>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
</body>
</html>