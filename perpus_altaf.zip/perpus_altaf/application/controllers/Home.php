<?php

class Home extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Peminjaman_model');
        $this->load->library('form_validation');
    }
    public function index()
    {
        $data['judul']= 'Daftar Peminjaman Buku';
        $data['buku'] = $this->Peminjaman_model->getAllData();
        $this->load->view('templates/header', $data);
        $this->load->view('home/index');
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $data['judul']= "Form Tambah Data Peminjaman Buku";

        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('nis', 'NIS', 'required');
        $this->form_validation->set_rules('kelas', 'Kelas', 'required');
        $this->form_validation->set_rules('judul_buku', 'Judul Buku', 'required');
        $this->form_validation->set_rules('tgl_pinjam', 'tgl pinjam', 'required');
        $this->form_validation->set_rules('tgl_kembali', 'tgl kembali', 'required');

        if($this->form_validation->run() == false){
            $this->load->view('templates/header');
            $this->load->view('home/tambah', $data);
            $this->load->view('templates/footer');
        }else{
            $this->Peminjaman_model->tambahData();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('home');
        }
    }

    public function hapus($id)
    {
        $this->Peminjaman_model->hapusData($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('home');
    }

    // public function detail($id)
    // {
    //     $data['judul'] = "Detail Data Mahasiswa";
    //     $data['mahasiswa'] = $this->Mahasiswa_model->getMahasiswaGetById($id);
    //     $this->load->view('templates/header', $data);
    //     $this->load->view('mahasiswa/detail');
    //     $this->load->view('templates/footer');
    // }

    public function ubah($id)
    {
        $data['judul']= "Form Ubah Data Peminjaman Buku";
        $data['buku'] = $this->Peminjaman_model->getDataGetById($id);
        // $data['jurusan'] = ['Rekayasa Perangkat Lunak', 'Transmisi', 'Teknik Jaringan Akses', 'Teknik Komputer Jaringan'];

        $this->form_validation->set_rules('nama_lengkap', 'Nama Lengkap', 'required');
        $this->form_validation->set_rules('nis', 'NIS', 'required');
        $this->form_validation->set_rules('kelas', 'Kelas', 'required');
        $this->form_validation->set_rules('judul_buku', 'Judul Buku', 'required');
        $this->form_validation->set_rules('tgl_pinjam', 'tgl pinjam', 'required');
        $this->form_validation->set_rules('tgl_kembali', 'tgl kembali', 'required');

        if($this->form_validation->run() == false){
            $this->load->view('templates/header', $data);
            $this->load->view('home/ubah', $data);
            $this->load->view('templates/footer');
        }else{
            $this->Peminjaman_model->ubahData();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('home');
        }
    }

} 