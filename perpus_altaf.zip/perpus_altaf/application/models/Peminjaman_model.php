<?php

class Peminjaman_model extends CI_Model {
    public function getAllData()
    {
        return $this->db->get('buku')->result_array();
        
    }

    public function tambahData()
    {
        $data = [
            "nama_lengkap" => $this->input->post('nama_lengkap', true),
            "nis" => $this->input->post('nis', true),
            "kelas" => $this->input->post('kelas', true),
            "judul_buku" => $this->input->post('judul_buku', true),
            "tgl_pinjam" => $this->input->post('tgl_pinjam', true),
            "tgl_kembali" => $this->input->post('tgl_kembali', true)
        ];

        $this->db->insert('buku', $data);
    }

    public function hapusData($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('buku', ['id' => $id]);
    }

    public function getDataGetById($id)
    {
        return $this->db->get_where('buku', ['id' => $id])->row_array();
    }

    public function ubahData()
    {
        $data = [
            "nama_lengkap" => $this->input->post('nama_lengkap', true),
            "nis" => $this->input->post('nis', true),
            "kelas" => $this->input->post('kelas', true),
            "judul_buku" => $this->input->post('judul_buku', true),
            "tgl_pinjam" => $this->input->post('tgl_pinjam', true),
            "tgl_kembali" => $this->input->post('tgl_kembali', true)
        ];
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('buku', $data);
    }
}